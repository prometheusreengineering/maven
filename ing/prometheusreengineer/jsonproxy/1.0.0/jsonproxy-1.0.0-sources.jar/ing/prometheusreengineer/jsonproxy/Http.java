package ing.prometheusreengineer.jsonproxy;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Request/response values. Bodies are bytes on the wire and JSON on demand. */
public final class Http {
    private Http() {}

    public record Req(String method, String path, String route, String query,
                      Map<String, List<String>> headers, byte[] body) {

        /** Path + query, as the client asked for it. */
        @Contract(pure = true)
        public String target() { return query == null || query.isEmpty() ? path : path + "?" + query; }

        @Contract(value = " -> new", pure = true)
        public @NotNull String bodyText() { return new String(body, StandardCharsets.UTF_8); }

        /** The request body as JSON, or null if absent / not JSON. */
        public Object json() { return Json.tryParse(body); }

        /** The request body as a JSON object (empty if absent / not an object). */
        public @NotNull Map<String, Object> jsonObject() { return Json.object(json()); }

        @Contract("_ -> new")
        public @NotNull Req withBody(byte[] b) { return new Req(method, path, route, query, headers, b); }

        @Contract("_ -> new")
        public @NotNull Req withJson(Object value) {
            // Copy before touching Content-Type: the caller still holds this map,
            // and a case-variant key would forward two Content-Type headers.
            Map<String, List<String>> h = new java.util.LinkedHashMap<>(headers);
            h.keySet().removeIf(k -> k.equalsIgnoreCase("Content-Type"));
            h.put("Content-Type", List.of("application/json"));
            return new Req(method, path, route, query, h, Json.bytes(value));
        }

        public String header(String name) { return Headers.first(headers, name); }

        public boolean isJson() { return Headers.isJson(headers); }
    }

    public record Res(int status, Map<String, List<String>> headers, byte[] body) {

        @Contract("_, _ -> new")
        public static @NotNull Res json(int status, Object value) { return jsonText(status, Json.write(value)); }

        @Contract("_, _ -> new")
        public static @NotNull Res jsonText(int status, @NotNull String rawJson) {
            return new Res(status, Headers.of("Content-Type", "application/json"),
                    rawJson.getBytes(StandardCharsets.UTF_8));
        }

        @Contract("_, _ -> new")
        public static @NotNull Res text(int status, @NotNull String body) {
            return new Res(status, Headers.of("Content-Type", "text/plain; charset=utf-8"),
                    body.getBytes(StandardCharsets.UTF_8));
        }

        @Contract("_ -> new")
        public static @NotNull Res empty(int status) { return new Res(status, Map.of(), new byte[0]); }

        @Contract(value = " -> new", pure = true)
        public @NotNull String bodyText() { return new String(body, StandardCharsets.UTF_8); }

        /** The response body as JSON, or null if absent / not JSON. */
        public Object json() { return Json.tryParse(body); }

        public @NotNull Map<String, Object> jsonObject() { return Json.object(json()); }

        @Contract("_ -> new")
        public @NotNull Res withBody(byte[] b) { return new Res(status, headers, b); }
        @Contract("_ -> new")
        public @NotNull Res withBody(@NotNull String b) { return withBody(b.getBytes(StandardCharsets.UTF_8)); }
        @Contract("_ -> new")
        public @NotNull Res withJson(Object value) { return withBody(Json.bytes(value)); }
        @Contract("_ -> new")
        public @NotNull Res withStatus(int s) { return new Res(s, headers, body); }

        public String header(String name) { return Headers.first(headers, name); }

        public boolean isJson() { return Headers.isJson(headers); }
    }

    /** Where the response the client received actually came from. */
    public enum Origin { UPSTREAM, LOCAL, REWRITTEN, ERROR }

    /**
     * One completed request/response pair, handed to every matching tap.
     *
     * @param res      what the client actually received (after any rewrite)
     * @param upstream the answer as it stood before any rewrite -- upstream's own,
     *                 or the one a rule gave in respond() -- or null when no rule
     *                 changed it
     */
    public record Exchange(Req req, Res res, Res upstream, Origin origin, long millis) {
        public Object responseJson() { return res.json(); }
        public Object requestJson() { return req.json(); }

        /** The unrewritten response when there is one, otherwise what the client got. */
        public Res original() { return upstream != null ? upstream : res; }
        public Object originalJson() { return original().json(); }
    }

    static final class Headers {
        @Contract("_, _ -> new")
        static @NotNull Map<String, List<String>> of(String name, String value) {
            return new java.util.LinkedHashMap<>(Map.of(name, List.of(value)));
        }

        static @Nullable String first(@NotNull Map<String, List<String>> headers, String name) {
            for (var e : headers.entrySet()) {
                if (e.getKey().equalsIgnoreCase(name) && !e.getValue().isEmpty()) return e.getValue().get(0);
            }
            return null;
        }

        static boolean isJson(Map<String, List<String>> headers) {
            String ct = first(headers, "Content-Type");
            return ct != null && ct.toLowerCase(Locale.ROOT).contains("json");
        }
    }
}
