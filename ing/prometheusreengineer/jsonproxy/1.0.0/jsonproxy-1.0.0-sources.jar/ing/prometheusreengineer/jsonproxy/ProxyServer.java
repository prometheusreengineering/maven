package ing.prometheusreengineer.jsonproxy;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;

import ing.prometheusreengineer.jsonproxy.Http.Exchange;
import ing.prometheusreengineer.jsonproxy.Http.Origin;
import ing.prometheusreengineer.jsonproxy.Http.Req;
import ing.prometheusreengineer.jsonproxy.Http.Res;

import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.NotNull;

/**
 * A loopback reverse proxy that speaks JSON. Embed it:
 *
 * <pre>{@code
 *   new ProxyServer(new Config()
 *           .port(8099).upstream("https://api.example.com").routePrefix("/v2")
 *           .rules(MyRules.ALL)).start();
 * }</pre>
 *
 * or run the jar for a pass-through logger with no rules at all.
 *
 * <p>Control endpoints (matched first, never forwarded):
 *
 * <pre>{@code
 *   GET /__proxy/rules
 *   GET /__proxy/captures
 *   GET /__proxy/captures/<slug>
 * }</pre>
 */
public final class ProxyServer {



    private static final Set<String> DROP_REQUEST = Set.of(
            "host", "connection", "keep-alive", "transfer-encoding", "upgrade", "expect",
            "content-length", "proxy-connection",
            "accept-encoding"); // ask upstream for identity; never hand the client gzip it didn't request
    private static final Set<String> DROP_RESPONSE = Set.of(
            "connection", "keep-alive", "transfer-encoding", "content-length", "content-encoding");

    private final Config config;
    private final Logger log;
    private final HttpClient client = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .followRedirects(HttpClient.Redirect.NEVER) // the client decides about redirects, not us
            .build();
    private HttpServer server;
    private ExecutorService pool;

    public ProxyServer(@NotNull Config config) {
        this.config = config;
        this.log = LogManager.getLogger(config.label);
    }

    public void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress(InetAddress.getLoopbackAddress(), config.port), 64);
        server.createContext("/", this::handle);
        // Daemon threads: embedded in a game, the proxy must not hold the JVM
        // open after the host decides to quit.
        AtomicInteger n = new AtomicInteger();
        pool = Executors.newFixedThreadPool(8, r -> {
            Thread t = new Thread(r, config.label + "-" + n.incrementAndGet());
            t.setDaemon(true);
            return t;
        });
        server.setExecutor(pool);
        server.start();
        log.info("listening on http://127.0.0.1:{}  ->  {}", config.port,
                config.offline ? "(offline: local rules only)" : config.upstream);
        log.info("rules: {}", ruleNames());
    }

    public void stop() {
        if (server != null) server.stop(0);
        if (pool != null) pool.shutdownNow();
    }

    public int port() { return server == null ? config.port : server.getAddress().getPort(); }

    // ---- pipeline -----------------------------------------------------------

    private void handle(@NotNull HttpExchange http) {
        long started = System.nanoTime();
        Req req;
        try (InputStream in = http.getRequestBody()) {
            String path = http.getRequestURI().getRawPath();
            String route = stripPrefix(path);
            req = new Req(http.getRequestMethod(), path, route, http.getRequestURI().getRawQuery(),
                    new LinkedHashMap<>(http.getRequestHeaders()), in.readAllBytes());
        } catch (IOException e) {
            http.close();
            return;
        }

        Res res;
        Res upstreamRes = null;   // pre-rewrite, for taps that want what upstream really said
        Origin origin;
        String note = "";

        if (req.path().startsWith("/__proxy")) {
            res = control(req);
            origin = Origin.LOCAL;
            note = " (control)";
        } else {
            List<Rule> matched = new ArrayList<>();
            for (Rule r : config.rules) {
                try {
                    if (r.matches(req)) matched.add(r);
                } catch (Exception e) { ruleError(r, "matches", e); }
            }

            // 1. request editing, chained
            for (Rule r : matched) {
                try {
                    Req edited = r.onRequest(req);
                    if (edited != null && edited != req) { req = edited; note = " (req:" + r.name() + ")"; }
                } catch (Exception e) { ruleError(r, "onRequest", e); }
            }

            // 2. local answer, first non-null wins
            Res answer = null;
            String answeredBy = null;
            for (Rule r : matched) {
                try {
                    Res candidate = r.respond(req);
                    if (candidate != null) { answer = candidate; answeredBy = r.name(); break; }
                } catch (Exception e) { ruleError(r, "respond", e); }
            }

            if (answer != null) {
                res = answer;
                origin = Origin.LOCAL;
                note = " (" + answeredBy + ")";
            } else if (config.offline) {
                res = Res.json(503, Json.map("error", "offline and no rule answered"));
                origin = Origin.ERROR;
                note = " (offline)";
            } else {
                try {
                    res = forward(req);
                    origin = Origin.UPSTREAM;
                } catch (Exception e) {
                    res = Res.json(502, Json.map("error", e.getClass().getSimpleName() + ": " + e.getMessage()));
                    origin = Origin.ERROR;
                    note = " (upstream failed)";
                }
            }

            // 3. response editing, chained -- over any real answer, upstream's or a
            //    rule's. Not over ERROR: a 502 is the proxy talking, not the exchange.
            if (origin == Origin.UPSTREAM || origin == Origin.LOCAL) {
                Res beforeRewrites = res;
                for (Rule r : matched) {
                    try {
                        Res out = r.transform(req, res);
                        if (out != null && out != res) { res = out; origin = Origin.REWRITTEN; note = " (" + r.name() + ")"; }
                    } catch (Exception e) { ruleError(r, "transform", e); }
                }
                if (res != beforeRewrites) upstreamRes = beforeRewrites;
            }

            // 4. taps, always
            Exchange exchange = new Exchange(req, res, upstreamRes, origin,
                    (System.nanoTime() - started) / 1_000_000);
            for (Rule r : matched) {
                try {
                    r.observe(exchange);
                } catch (Exception e) { ruleError(r, "observe", e); }
            }
        }

        if (config.verbose) {
            dump("->", req.method() + " " + req.target(), req.headers(), req.body());
            dump("<-", res.status() + " " + origin, res.headers(), res.body());
        }

        try (http) {
            send(http, res);
        } catch (IOException io) {
            note += " [send failed: " + io.getMessage() + "]";
        } finally {
            log.printf(Level.INFO, "%-4s %-44s -> %d %-9s%s  %dB  %dms",
                    req.method(), req.target(), res.status(), origin, note,
                    res.body().length, (System.nanoTime() - started) / 1_000_000);
        }
    }

    /**
     * The path with {@link Config#routePrefix} removed, but only when the prefix
     * ends on a segment boundary -- "/v2" must not turn "/v2000/x" into "000/x".
     */
    private String stripPrefix(String path) {
        String prefix = config.routePrefix;
        if (prefix.isEmpty() || !path.startsWith(prefix)) return path;
        if (path.length() == prefix.length()) return "/";
        if (path.charAt(prefix.length()) != '/') return path;   // not a segment boundary
        return path.substring(prefix.length());
    }

    private @NotNull Res control(@NotNull Req req) {
        String p = req.path().substring("/__proxy".length());
        if (p.equals("/rules")) return Res.json(200, ruleNames());
        if (p.equals("/captures")) return Res.json(200, Captures.index());
        if (p.startsWith("/captures/")) {
            Exchange x = Captures.latest(p.substring("/captures/".length()));
            if (x == null) return Res.json(404, Json.map("error", "nothing captured under that slug"));
            return new Res(200, x.res().headers(), x.res().body());
        }
        return Res.json(404, Json.map("error", "unknown control endpoint"));
    }

    private @NotNull List<String> ruleNames() {
        List<String> names = new ArrayList<>();
        for (Rule r : config.rules) names.add(r.name());
        return names;
    }

    private void ruleError(@NotNull Rule rule, String phase, Exception e) {
        log.warn("rule '{}' threw in {}(): {}", rule.name(), phase, e);
    }

    // ---- upstream -----------------------------------------------------------

    private Res forward(Req req) throws IOException, InterruptedException {
        HttpRequest.Builder b = HttpRequest.newBuilder(URI.create(config.upstream + req.target()))
                .timeout(Duration.ofSeconds(20))
                .method(req.method(), req.body().length == 0
                        ? HttpRequest.BodyPublishers.noBody()
                        : HttpRequest.BodyPublishers.ofByteArray(req.body()));

        req.headers().forEach((name, values) -> {
            if (DROP_REQUEST.contains(name.toLowerCase(Locale.ROOT))) return;
            for (String v : values) b.header(name, v);
        });

        HttpResponse<byte[]> up = client.send(b.build(), HttpResponse.BodyHandlers.ofByteArray());

        Map<String, List<String>> headers = new LinkedHashMap<>();
        up.headers().map().forEach((name, values) -> {
            if (name.startsWith(":")) return; // HTTP/2 pseudo-headers are not real headers
            // Response headers can carry state the client needs (an API that rotates
            // its access token out of Authorization), so keep all but hop-by-hop.
            if (!DROP_RESPONSE.contains(name.toLowerCase(Locale.ROOT))) headers.put(name, values);
        });
        return new Res(up.statusCode(), headers, up.body());
    }

    private void send(HttpExchange http, Res res) throws IOException {
        res.headers().forEach((name, values) -> {
            if (DROP_RESPONSE.contains(name.toLowerCase(Locale.ROOT))) return;
            http.getResponseHeaders().put(name, new ArrayList<>(values));
        });
        byte[] body = res.body();
        boolean bodyless = body.length == 0 || res.status() == 204 || res.status() == 304;
        http.sendResponseHeaders(res.status(), bodyless ? -1 : body.length);
        if (!bodyless) {
            try (OutputStream out = http.getResponseBody()) { out.write(body); }
        }
    }

    private void dump(String arrow, String line, @NotNull Map<String, List<String>> headers, byte @NotNull [] body) {
        StringBuilder sb = new StringBuilder("  ").append(arrow).append(' ').append(line);
        headers.forEach((k, v) -> sb.append("\n     ").append(k).append(": ").append(String.join(", ", v)));
        if (body.length > 0) {
            Object json = Json.tryParse(body);
            String s = json != null ? Json.pretty(json) : new String(body, StandardCharsets.UTF_8);
            sb.append("\n     ").append(s.replace("\n", "\n     "));
        }
        log.info(sb);
    }

    // ---- standalone ---------------------------------------------------------

    public static void main(String[] args) throws Exception {
        Config config = new Config();
        List<String> a = Arrays.asList(args);
        for (int i = 0; i < a.size(); i++) {
            switch (a.get(i)) {
                case "--port" -> config.port(Integer.parseInt(a.get(++i)));
                case "--upstream" -> config.upstream(a.get(++i));
                case "--prefix" -> config.routePrefix(a.get(++i));
                case "--offline" -> config.offline(true);
                case "-v", "--verbose" -> config.verbose(true);
                default -> {
                    System.err.println("usage: ProxyServer --upstream URL [--port N] [--prefix /v2] [--offline] [-v]");
                    System.exit(2);
                }
            }
        }
        if (config.upstream.isEmpty() && !config.offline) {
            System.err.println("--upstream is required (or --offline)");
            System.exit(2);
        }
        new ProxyServer(config).start();
    }
}
