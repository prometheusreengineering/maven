package ing.prometheusreengineer.jsonproxy;

import java.util.Objects;
import java.util.function.Predicate;
import java.util.regex.Pattern;

import ing.prometheusreengineer.jsonproxy.Http.Req;
import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.NotNullByDefault;

/**
 * Predicates over {@link Req#route()} -- the path with the server's route prefix
 * stripped, so rules name endpoints the way the upstream API documents them.
 * <br>
 * Globs: '*' matches within one segment, '**' matches across segments.
 */
@NotNullByDefault
@SuppressWarnings({"unused","UnstableApiUsage"})
public final class Match {
    private Match() {}

    public static Predicate<Req> any() { return req -> true; }

    public static Predicate<Req> method(String method) {
        return req -> req.method().equalsIgnoreCase(method);
    }

    public static Predicate<Req> route(String glob) {
        Pattern p = compile(glob);
        return req -> p.matcher(req.route()).matches();
    }

    public static Predicate<Req> get(String glob) { return method("GET").and(route(glob)); }
    public static Predicate<Req> put(String glob) { return method("PUT").and(route(glob)); }
    public static Predicate<Req> post(String glob) { return method("POST").and(route(glob)); }
    public static Predicate<Req> patch(String glob) { return method("PATCH").and(route(glob)); }
    public static Predicate<Req> delete(String glob) { return method("DELETE").and(route(glob)); }

    /** Request body contains this substring -- handy for conditional writes. */
    @Contract(pure = true)
    public static Predicate<Req> bodyContains(String needle) {
        return req -> req.bodyText().contains(needle);
    }

    /** Request JSON has this dotted path equal to this value. */
    @Contract(pure = true)
    public static Predicate<Req> jsonEquals(String path, Object value) {
        return req -> {
            Object actual = Json.get(req.json(), path);
            return Objects.equals(value, actual);
        };
    }

    /** Request declares a JSON body. */
    @Contract(pure = true)
    public static Predicate<Req> jsonBody() { return Req::isJson; }

    private static Pattern compile(String glob) {
        StringBuilder re = new StringBuilder("^");
        for (int i = 0; i < glob.length(); i++) {
            char c = glob.charAt(i);
            if (c == '*') {
                if (i + 1 < glob.length() && glob.charAt(i + 1) == '*') { re.append(".*"); i++; }
                else re.append("[^/]*");
            } else if ("\\.[]{}()+-^$|?".indexOf(c) >= 0) {
                re.append('\\').append(c);
            } else {
                re.append(c);
            }
        }
        return Pattern.compile(re.append('$').toString(), Pattern.CASE_INSENSITIVE);
    }
}
