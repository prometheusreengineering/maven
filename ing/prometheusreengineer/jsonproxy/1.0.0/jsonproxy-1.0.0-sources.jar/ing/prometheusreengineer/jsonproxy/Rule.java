package ing.prometheusreengineer.jsonproxy;

import java.util.function.Predicate;

import ing.prometheusreengineer.jsonproxy.Http.Exchange;
import ing.prometheusreengineer.jsonproxy.Http.Req;
import ing.prometheusreengineer.jsonproxy.Http.Res;

/**
 * One hook in the pipeline. Every rule whose {@link #matches} returns true takes
 * part; there is no first-match-wins except where a rule deliberately answers a
 * request.
 * <br>
 * Per request the proxy runs, in order:
 *   1. onRequest(req)       -- edit the outgoing request (body, JSON, headers).
 *                              Chained: each rule sees the previous one's output.
 *   2. respond(req)         -- answer it yourself. First non-null wins: no later
 *                              rule's respond() is called and nothing is sent
 *                              upstream. Returning null means "not mine", so a
 *                              write is only canceled when a rule chooses to.
 *   2.5. Request is sent upstream (assuming no respond() returned non-null).
 *   3. transform(req, res)  -- edit the response, whoever produced it: upstream's
 *                              answer or a rule's. Chained, same as onRequest.
 *   4. observe(exchange)    -- read-only tap. Every matching rule, always, including
 *                              locally answered and failed exchanges.
 * <br>
 * A rule that throws is logged and skipped; it never breaks the request.
 * <br>
 * The *Json builders hand you parsed JSON (plain Map/List/String/Number/Boolean,
 * see {@link Json}) and re-serialize whatever you return -- the document is yours
 * to mutate in place. Return null from an editor to leave the body untouched; a
 * non-JSON body passes through them untouched either way.
 */
public interface Rule {
    default String name() { return getClass().getSimpleName(); }

    boolean matches(Req req);

    /** Edit the request before it goes upstream. Return it unchanged for a no-op. */
    default Req onRequest(Req req) throws Exception { return req; }

    /**
     * Answer the request yourself, so nothing is sent upstream. Return null to
     * let it go. The first rule to answer ends this phase; the exchange then
     * carries on through transform() and observe() as any other would.
     */
    default Res respond(Req req) throws Exception { return null; }

    /**
     * Edit the response on its way back -- upstream's, or one a rule answered
     * with. Return it unchanged for a no-op.
     */
    default Res transform(Req req, Res res) throws Exception { return res; }

    /** Read-only tap: mutating nothing, seeing everything. */
    default void observe(Exchange exchange) throws Exception {}

    // ---- functional shapes --------------------------------------------------

    interface ReqEditor { Req apply(Req req) throws Exception; }
    interface Responder { Res apply(Req req) throws Exception; }
    interface Transformer { Res apply(Req req, Res res) throws Exception; }
    interface Tap { void accept(Exchange exchange) throws Exception; }

    /** (request, parsed JSON) -> replacement document, or null to leave the body alone. */
    interface JsonEditor { Object apply(Req req, Object json) throws Exception; }
    /** (request, parsed request JSON) -> response document, or null to pass through. */
    interface JsonResponder { Object apply(Req req, Object requestJson) throws Exception; }
    /** (exchange, parsed response JSON) -> void. */
    interface JsonTap { void accept(Exchange exchange, Object responseJson) throws Exception; }

    // ---- byte-level builders ------------------------------------------------

    static Rule editRequest(String name, Predicate<Req> when, ReqEditor f) {
        return new Base(name, when) {
            @Override public Req onRequest(Req req) throws Exception { return f.apply(req); }
        };
    }

    static Rule respond(String name, Predicate<Req> when, Responder f) {
        return new Base(name, when) {
            @Override public Res respond(Req req) throws Exception { return f.apply(req); }
        };
    }

    static Rule rewrite(String name, Predicate<Req> when, Transformer f) {
        return new Base(name, when) {
            @Override public Res transform(Req req, Res res) throws Exception { return f.apply(req, res); }
        };
    }

    static Rule tap(String name, Predicate<Req> when, Tap f) {
        return new Base(name, when) {
            @Override public void observe(Exchange exchange) throws Exception { f.accept(exchange); }
        };
    }

    // ---- JSON-level builders ------------------------------------------------

    /**
     * Edit the outgoing request's JSON body. The document handed in is yours to
     * mutate in place; return it (or a new one) to apply, or null to leave the
     * body untouched.
     */
    static Rule editRequestJson(String name, Predicate<Req> when, JsonEditor f) {
        return new Base(name, when) {
            @Override public Req onRequest(Req req) throws Exception {
                Object json = req.json();
                if (json == null) return req;               // not JSON: leave it alone
                Object edited = f.apply(req, json);
                return edited == null ? req : req.withJson(edited);
            }
        };
    }

    /** Answer with a JSON document (HTTP 200), or return null to pass upstream. */
    static Rule respondJson(String name, Predicate<Req> when, JsonResponder f) {
        return new Base(name, when) {
            @Override public Res respond(Req req) throws Exception {
                Object body = f.apply(req, req.json());
                return body == null ? null : Res.json(200, body);
            }
        };
    }

    /**
     * Edit the response's JSON body on the way back. The document handed in is
     * yours to mutate in place; return it (or a new one) to apply, or null to
     * leave the body untouched.
     */
    static Rule rewriteJson(String name, Predicate<Req> when, JsonEditor f) {
        return new Base(name, when) {
            @Override public Res transform(Req req, Res res) throws Exception {
                Object json = res.json();
                if (json == null) return res;               // not JSON: leave it alone
                Object edited = f.apply(req, json);
                return edited == null ? res : res.withJson(edited);
            }
        };
    }

    /** Read the response as JSON without changing anything. */
    static Rule tapJson(String name, Predicate<Req> when, JsonTap f) {
        return new Base(name, when) {
            @Override public void observe(Exchange exchange) throws Exception {
                f.accept(exchange, exchange.res().json());
            }
        };
    }

    abstract class Base implements Rule {
        private final String name;
        private final Predicate<Req> when;
        protected Base(String name, Predicate<Req> when) { this.name = name; this.when = when; }
        @Override public String name() { return name; }
        @Override public boolean matches(Req req) { return when.test(req); }
    }
}
