package ing.prometheusreengineer.jsonproxy;

import org.jetbrains.annotations.Contract;
import org.jetbrains.annotations.NotNullByDefault;
import org.jetbrains.annotations.Nullable;
import org.jetbrains.annotations.Unmodifiable;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Dependency-free JSON for arbitrary blobs. No schema, no binding, no GSON:
 * documents are plain Java values, so a rule can dig into anything an upstream
 * sends without a model class for it.
 *
 * <pre>{@code
 *   object -> LinkedHashMap<String,Object> (insertion ordered)
 *   array  -> ArrayList<Object>
 *   string -> String      number -> Long or Double
 *   bool   -> Boolean     null   -> null
 * }</pre>
 */
@NotNullByDefault
@SuppressWarnings({"unused", "UnstableApiUsage"})
public final class Json {
    private Json() {}

    // ---- parse --------------------------------------------------------------

    public static Object parse(String text) { return new Parser(text).parseDocument(); }

    public static Object parse(byte[] bytes) { return parse(new String(bytes, StandardCharsets.UTF_8)); }

    /** Parse, or null if the text is not valid JSON. Handy for best-effort taps. */
    public static @Nullable Object tryParse(byte[] bytes) {
        if (bytes.length == 0) return null;
        try { return parse(bytes); } catch (RuntimeException e) { return null; }
    }

    // ---- write --------------------------------------------------------------

    public static String write(Object value) {
        StringBuilder sb = new StringBuilder();
        write(value, sb, -1, 0);
        return sb.toString();
    }

    public static String pretty(Object value) {
        StringBuilder sb = new StringBuilder();
        write(value, sb, 2, 0);
        return sb.toString();
    }

    public static byte[] bytes(Object value) { return write(value).getBytes(StandardCharsets.UTF_8); }

    // ---- shaping helpers ----------------------------------------------------

    /** The value as a mutable object, or an empty one if it is not an object. */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> object(Object value) {
        return value instanceof Map ? (Map<String, Object>) value : new LinkedHashMap<>();
    }

    /** The value as a mutable array, or an empty one if it is not an array. */
    @Contract(value = "null -> new", pure = true)
    @SuppressWarnings("unchecked")
    public static List<Object> array(@Nullable Object value) {
        return value instanceof List ? (List<Object>) value : new ArrayList<>();
    }

    /** Build an object inline: Json.map("status", "ONLINE", "ok", true). */
    public static Map<String, Object> map(Object... keyValues) {
        if (keyValues.length % 2 != 0) throw new IllegalArgumentException("odd key/value count");
        Map<String, Object> m = new LinkedHashMap<>();
        for (int i = 0; i < keyValues.length; i += 2) m.put(String.valueOf(keyValues[i]), keyValues[i + 1]);
        return m;
    }

    /** Dig with a dotted path: get(doc, "location.city"), get(doc, "items[0].id"). */
    @Contract(value = "null, _ -> null", pure = true)
    public static @Nullable Object get(@Nullable Object root, String path) {
        Object cur = root;
        for (String part : path.split("\\.")) {
            if (cur == null) return null;
            String key = part;
            int bracket = part.indexOf('[');
            if (bracket >= 0) {
                key = part.substring(0, bracket);
                if (!key.isEmpty()) cur = object(cur).get(key);
                for (String idx : part.substring(bracket).split("\\[")) {
                    if (idx.isEmpty()) continue;
                    int i = Integer.parseInt(idx.replace("]", "").trim());
                    List<Object> list = array(cur);
                    cur = i >= 0 && i < list.size() ? list.get(i) : null;
                }
            } else {
                cur = object(cur).get(key);
            }
        }
        return cur;
    }

    /** Set with a dotted path, creating intermediate objects as needed. */
    public static void set(Object root, String path, Object value) {
        String[] parts = path.split("\\.");
        Map<String, Object> cur = object(root);
        for (int i = 0; i < parts.length - 1; i++) {
            Object next = cur.get(parts[i]);
            if (!(next instanceof Map)) { next = new LinkedHashMap<String, Object>(); cur.put(parts[i], next); }
            cur = object(next);
        }
        cur.put(parts[parts.length - 1], value);
    }

    // ---- internals ----------------------------------------------------------

    private static void write(@Nullable Object value, StringBuilder sb, int indent, int depth) {
        if (value == null) { sb.append("null"); return; }
        if (value instanceof String s) { escape(s, sb); return; }
        if (value instanceof Number || value instanceof Boolean) { sb.append(value); return; }

        boolean isMap = value instanceof Map;
        if (!isMap && !(value instanceof List)) { escape(String.valueOf(value), sb); return; }

        String nl = indent < 0 ? "" : "\n";
        String pad = indent < 0 ? "" : " ".repeat(indent * (depth + 1));
        String padEnd = indent < 0 ? "" : " ".repeat(indent * depth);
        String colon = indent < 0 ? ":" : ": ";

        if (isMap) {
            Map<?, ?> m = (Map<?, ?>) value;
            if (m.isEmpty()) { sb.append("{}"); return; }
            sb.append('{').append(nl);
            boolean first = true;
            for (Map.Entry<?, ?> e : m.entrySet()) {
                if (!first) sb.append(',').append(nl);
                first = false;
                sb.append(pad);
                escape(String.valueOf(e.getKey()), sb);
                sb.append(colon);
                write(e.getValue(), sb, indent, depth + 1);
            }
            sb.append(nl).append(padEnd).append('}');
        } else {
            List<?> list = (List<?>) value;
            if (list.isEmpty()) { sb.append("[]"); return; }
            sb.append('[').append(nl);
            for (int i = 0; i < list.size(); i++) {
                if (i > 0) sb.append(',').append(nl);
                sb.append(pad);
                write(list.get(i), sb, indent, depth + 1);
            }
            sb.append(nl).append(padEnd).append(']');
        }
    }

    private static void escape(String s, StringBuilder sb) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"' -> sb.append("\\\"");
                case '\\' -> sb.append("\\\\");
                case '\n' -> sb.append("\\n");
                case '\r' -> sb.append("\\r");
                case '\t' -> sb.append("\\t");
                case '\b' -> sb.append("\\b");
                case '\f' -> sb.append("\\f");
                default -> { if (c < 0x20) sb.append(String.format("\\u%04x", (int) c)); else sb.append(c); }
            }
        }
        sb.append('"');
    }

    private static final class Parser {
        private final String s;
        private int i;

        Parser(String s) { this.s = s; }

        Object parseDocument() {
            Object v = parseValue();
            skipWhitespace();
            if (i < s.length()) throw err("trailing content");
            return v;
        }

        private @Nullable Object parseValue() {
            skipWhitespace();
            if (i >= s.length()) throw err("unexpected end");
            char c = s.charAt(i);
            return switch (c) {
                case '{' -> parseObject();
                case '[' -> parseArray();
                case '"' -> parseString();
                case 't' -> literal("true", Boolean.TRUE);
                case 'f' -> literal("false", Boolean.FALSE);
                case 'n' -> literal("null", null);
                default -> parseNumber();
            };
        }

        private Map<String, Object> parseObject() {
            Map<String, Object> m = new LinkedHashMap<>();
            expect('{');
            skipWhitespace();
            if (peek() == '}') { i++; return m; }
            while (true) {
                skipWhitespace();
                String key = parseString();
                skipWhitespace();
                expect(':');
                m.put(key, parseValue());
                skipWhitespace();
                char c = next();
                if (c == '}') return m;
                if (c != ',') throw err("expected , or }");
            }
        }

        private List<Object> parseArray() {
            List<Object> list = new ArrayList<>();
            expect('[');
            skipWhitespace();
            if (peek() == ']') { i++; return list; }
            while (true) {
                list.add(parseValue());
                skipWhitespace();
                char c = next();
                if (c == ']') return list;
                if (c != ',') throw err("expected , or ]");
            }
        }

        private String parseString() {
            expect('"');
            StringBuilder sb = new StringBuilder();
            while (true) {
                char c = next();
                if (c == '"') return sb.toString();
                if (c != '\\') { sb.append(c); continue; }
                char e = next();
                switch (e) {
                    case '"', '\\', '/' -> sb.append(e);
                    case 'b' -> sb.append('\b');
                    case 'f' -> sb.append('\f');
                    case 'n' -> sb.append('\n');
                    case 'r' -> sb.append('\r');
                    case 't' -> sb.append('\t');
                    case 'u' -> { sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); i += 4; }
                    default -> throw err("bad escape \\" + e);
                }
            }
        }

        private @Unmodifiable Object parseNumber() {
            int start = i;
            while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
            String num = s.substring(start, i);
            if (num.isEmpty()) throw err("unexpected character '" + s.charAt(start) + "'");
            if (num.indexOf('.') < 0 && num.indexOf('e') < 0 && num.indexOf('E') < 0) {
                try { return Long.valueOf(num); } catch (NumberFormatException ignored) { /* fall through */ }
            }
            return Double.valueOf(num);
        }

        @Contract("_, _ -> param2")
        private @Nullable Object literal(String word, @Nullable Object value) {
            if (!s.startsWith(word, i)) throw err("expected " + word);
            i += word.length();
            return value;
        }

        private void skipWhitespace() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
        private char peek() { return i < s.length() ? s.charAt(i) : '\0'; }
        private char next() { if (i >= s.length()) throw err("unexpected end"); return s.charAt(i++); }
        private void expect(char c) { if (next() != c) throw err("expected '" + c + "'"); }
        @Contract(value = "_ -> new", pure = true)
        private RuntimeException err(String msg) { return new IllegalArgumentException("JSON at " + i + ": " + msg); }
    }
}
