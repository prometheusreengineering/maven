package ing.prometheusreengineer.jsonproxy;

import org.jetbrains.annotations.NotNullByDefault;

import java.nio.file.Path;
import java.util.List;

@NotNullByDefault
@SuppressWarnings({"unused", "UnusedReturnValue", "UnstableApiUsage"})
public final class Config {
    int port = 8099;
    String upstream = "";
    String routePrefix = "";
    boolean offline;
    boolean verbose;
    List<Rule> rules = List.of();
    String label = "jsonproxy";

    public Config port(int v) { port = v; return this; }
    public Config upstream(String v) { upstream = v.replaceAll("/+$", ""); return this; }
    /**
     * Stripped from the path to produce Req.route(), e.g. "/v2". Normalised to a
     * leading slash and no trailing one, so "v2/" and "/v2" behave the same.
     */
    public Config routePrefix(String v) {
        String p = v.trim().replaceAll("/+$", "");
        if (!p.isEmpty() && !p.startsWith("/")) p = "/" + p;
        routePrefix = p;
        return this;
    }
    public Config offline(boolean v) { offline = v; return this; }
    public Config verbose(boolean v) { verbose = v; return this; }
    public Config rules(List<Rule> v) { rules = List.copyOf(v); return this; }
    /** Doubles as the log4j logger name, so each proxy is filterable on its own. */
    public Config label(String v) { label = v; return this; }
    public Config captureDir(Path v) { Captures.directory(v); return this; }

    public int port() { return port; }
    public String upstream() { return upstream; }
}