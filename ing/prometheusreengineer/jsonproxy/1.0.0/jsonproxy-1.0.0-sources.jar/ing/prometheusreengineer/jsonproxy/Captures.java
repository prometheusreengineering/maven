package ing.prometheusreengineer.jsonproxy;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import ing.prometheusreengineer.jsonproxy.Http.Exchange;
import ing.prometheusreengineer.jsonproxy.Http.Req;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.jetbrains.annotations.Unmodifiable;

/**
 * Where data pulled out of responses lands: newest-per-route in memory for rules
 * to read, plus one JSON envelope per exchange on disk. Use it as a tap:
 *
 *   Rule.tap("capture", Match.get("/**"), Captures::record)
 *
 * Live view while the game runs:
 *   curl -s localhost:8099/__proxy/captures | jq
 *   curl -s localhost:8099/__proxy/captures/get.profile.me
 */
public final class Captures {
    private static final Logger LOG = LogManager.getLogger("jsonproxy");

    private Captures() {}

    private static volatile Path dir = Path.of("captures");
    private static volatile boolean toDisk = true;
    private static final Map<String, Exchange> LATEST = new ConcurrentHashMap<>();
    private static final AtomicInteger SEQ = new AtomicInteger();

    public static void directory(Path d) { dir = d; }
    public static void writeToDisk(boolean enabled) { toDisk = enabled; }

    public static void record(Exchange x) {
        LATEST.put(slug(x.req()), x);
        if (!toDisk) return;
        try {
            Files.createDirectories(dir);
            String file = String.format("%04d-%s.json", SEQ.incrementAndGet(), slug(x.req()));
            Files.writeString(dir.resolve(file), Json.pretty(envelope(x)) + "\n", StandardCharsets.UTF_8);
        } catch (IOException e) {
            LOG.warn("capture write failed", e);
        }
    }

    /** Newest exchange for a route, e.g. latest("get.profile.me"). */
    public static Exchange latest(String slug) { return LATEST.get(slug); }

    /** Newest response body for a route, already parsed. */
    public static Object latestJson(String slug) {
        Exchange x = LATEST.get(slug);
        return x == null ? null : x.res().json();
    }

    public static @Unmodifiable Map<String, Exchange> all() { return Map.copyOf(LATEST); }

    public static String slug(Req req) {
        return (req.method() + req.route()).toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", ".").replaceAll("(^\\.|\\.$)", "");
    }

    static Object index() {
        List<Object> rows = new ArrayList<>();
        LATEST.forEach((slug, x) -> rows.add(Json.map(
                "slug", slug,
                "method", x.req().method(),
                "route", x.req().route(),
                "status", (long) x.res().status(),
                "origin", x.origin().toString(),
                "ms", x.millis(),
                "bytes", (long) x.res().body().length)));
        return rows;
    }

    /** The on-disk envelope: metadata plus the bodies, as JSON when they are JSON. */
    private static Object envelope(Exchange x) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("method", x.req().method());
        m.put("target", x.req().target());
        m.put("status", (long) x.res().status());
        m.put("origin", x.origin().toString());
        m.put("ms", x.millis());
        if (x.req().body().length > 0) m.put("request", bodyOf(x.req().json(), x.req().bodyText()));
        m.put("response_headers", headerMap(x));
        m.put("response", bodyOf(x.res().json(), x.res().bodyText()));
        if (x.upstream() != null) {   // a rule changed it; keep what upstream really said
            m.put("upstream_response", bodyOf(x.upstream().json(), x.upstream().bodyText()));
        }
        return m;
    }

    private static Object bodyOf(Object parsed, String raw) { return parsed != null ? parsed : raw; }

    private static Map<String, Object> headerMap(Exchange x) {
        Map<String, Object> h = new LinkedHashMap<>();
        x.res().headers().forEach((k, v) -> h.put(k, String.join(", ", v)));
        return h;
    }
}
